import os
import subprocess

for file in os.listdir():
    if not file.lower().endswith(".ogg"):
        print(file)
        try:
            output = os.path.splitext(file)[0]+".ogg"
            subprocess.run(("ffmpeg", "-i", file, "-c:a","libvorbis", output))
        except Exception as e:
            print(e)